import { AzureFunction, Context, HttpRequest } from "@azure/functions"
import { CosmosClient } from "@azure/cosmos";

const endpoint = process.env.COSMOS_ENDPOINT || "";
const key = process.env.COSMOS_KEY || "";
const client = new CosmosClient({ endpoint, key });
const database = client.database("SankuCRM");

const httpTrigger: AzureFunction = async function (context: Context, req: HttpRequest): Promise<void> {
    const entityName = context.bindingData.entityName;
    const container = database.container(entityName);

    try {
        if (req.method === "GET") {
            const id = context.bindingData.id;
            if (id) {
                const { resource } = await container.item(id, id).read();
                context.res = { status: resource ? 200 : 404, body: resource };
                return;
            }
            const { resources } = await container.items.readAll().fetchAll();
            context.res = { body: resources };
            return;
        }

        if (req.method === "POST" || req.method === "PATCH") {
            const body = req.body;
            if (req.method === "POST" && !body.id) {
                body.id = Math.random().toString(36).substring(2, 11);
            }
            const { resource } = await container.items.upsert(body);
            context.res = { status: 201, body: resource };
            return;
        }

        if (req.method === "DELETE") {
            const id = context.bindingData.id;
            if (!id) {
                context.res = { status: 400, body: "ID required" };
                return;
            }
            await container.item(id, id).delete();
            context.res = { status: 204 };
            return;
        }

        context.res = { status: 405, body: "Method Not Allowed" };
    } catch (error: any) {
        context.log.error(`Error processing ${entityName}: ${error.message}`);
        context.res = { status: 500, body: error.message };
    }
};

export default httpTrigger;
